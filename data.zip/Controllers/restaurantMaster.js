const errorHandle = require("../services/errorHandler");
const commonMsgs = require("../CommonMsg.json");
const utiityFile = require("../utility");
const { poolPromise, sql } = require("../db");
var API_Services = require("../services/API_services");

class RestaurantMasterController {
  async getData(req, res) {
    try {
      const pool = await poolPromise;
      if (!req.query.RestaurantId) {
        let result = await pool.query(
          `SELECT RestaurantId,
          BranchCode,
          RestaurantName,
          GSTIN,
          Description,
          HotelLocnId,
          Address1,
          Address2,
          Zipcode,
          City,
          District,
          State,
          Latitude,
          Longitude,
          RestaurantManager,
          convert(char(5), OrderFrom, 108) as OrderFrom,
          convert(char(5), OrderTo, 108) as OrderTo,
          WorkingDays,
          ActiveStatus,
          MailId,
          CreatedBy,
          CreatedDate,
          UpdatedBy,
          UpdatedDate
          FROM RestaurantMaster`
        );
        res.json({ status: true, data: result.recordset });
      } else {
        let result = await pool.query(
          `select * from RestaurantMaster where RestaurantId= ${req.query.RestaurantId}`
        );
        res.json({ status: true, data: result.recordset });
      }
    } catch (error) {
      errorHandle.handleError(error, errorRes => {
        res.send(errorRes);
      });
    }
  }

  async getAllRestaurant(req, res){
    const pool = await poolPromise;
    let result = await pool.query(
      `SELECT * FROM RestaurantMaster`
    )
    if(result.recordset.length>0){
      res.json({ status: true, data: result.recordset });
    }else{
      res.json({ status: true, data: [] });
    }
  }
    
  async addData(req, res) {
    try {
      if (
        !(
          req.body.RestaurantId &&
          req.body.BranchCode &&
          req.body.RestaurantName &&
          req.body.GSTIN &&
          req.body.HotelLocnId &&
          req.body.Address1 &&
          req.body.Zipcode &&
          req.body.City &&
          req.body.District &&
          req.body.State &&
          req.body.Latitude &&
          req.body.Longitude &&
          req.body.Description &&
          req.body.RestaurantManager &&
          req.body.OrderFrom &&
          req.body.OrderTo &&
          req.body.WorkingDays &&
          req.body.CreatedBy
        )
      )
        res.json(commonMsgs.NullMsg);
      else {
        let ColNameQuery = "ActiveStatus",
          ColValueQuery = "'A'";
        for (let key in req.body) {
          if (req.body[key]) {
            ColNameQuery += `${ColNameQuery != `` ? `,` : ``}${key}`;
            ColValueQuery += `${ColValueQuery != `` ? `,` : ``}'${
              req.body[key]
            }'`;
          }
        }
        const pool = await poolPromise;
        let result = await pool.query(
          `INSERT INTO RestaurantMaster(${ColNameQuery}) VALUES(${ColValueQuery})`
        );
        res.json(commonMsgs.AddMsg);
      }
    } catch (error) {
      errorHandle.handleError(error, errorRes => {
        res.send(errorRes);
      });
    }
  }
  async updateData(req, res) {
    try {
      const { RestaurantId, UpdatedBy } = req.body;
      if (!RestaurantId || !UpdatedBy) return res.json(commonMsgs.NullMsg);
      let queryValue = null;
      for (const [key, value] of Object.entries(req.body)) {
        if (key != "RestaurantId")
          queryValue == null
            ? (queryValue = `${key}='${value}'`)
            : (queryValue += `,${key}='${value}'`);
      }
      const pool = await poolPromise;
      await pool.query(
        `UPDATE RestaurantMaster SET ${queryValue}, UpdatedDate = GETDATE()  WHERE RestaurantId = ${RestaurantId} `
      );
      res.json(commonMsgs.updateMsg);
    } catch (error) {
      errorHandle.handleError(error, errorRes => {
        res.send(errorRes);
      });
    }
  }
  async deleteData(req, res) {
    const { ActiveStatus, RestaurantId } = req.query;
    try {
      if (!RestaurantId || !ActiveStatus) return res.json(commonMsgs.NullMsg);
      const pool = await poolPromise;
      await pool.query(
        `UPDATE RestaurantMaster SET ActiveStatus = '${ActiveStatus}'  WHERE RestaurantId = '${RestaurantId}'`
      );
      res.json(commonMsgs.deleteMsg);
    } catch (error) {
      errorHandle.handleError(error, errorRes => {
        res.send(errorRes);
      });
    }
  }
}

const restaurantMaster = new RestaurantMasterController();

module.exports = restaurantMaster;
